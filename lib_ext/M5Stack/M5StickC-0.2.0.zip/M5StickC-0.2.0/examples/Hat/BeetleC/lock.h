#ifndef __LOCK_H
#define __LOCK_H

//min may error here
#undef min
#include <mutex>

std::mutex g_mutex;

#endif
