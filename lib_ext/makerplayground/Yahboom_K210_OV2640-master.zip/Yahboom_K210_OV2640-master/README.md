# Yahboom_K210_OV2640

Library to interface with OV2640 camera module on Yahboom K210 Development Kit. Adapt from Sipeed_OV2640 library in the [Maixduino project](https://github.com/sipeed/Maixduino/tree/master/libraries/Sipeed_OV2640)