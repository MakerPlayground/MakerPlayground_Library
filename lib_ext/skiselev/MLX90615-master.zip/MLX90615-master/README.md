# MLX90615
A minimal Arduino library for Melexis MLX90615 Infra-red Temperature Sensor
