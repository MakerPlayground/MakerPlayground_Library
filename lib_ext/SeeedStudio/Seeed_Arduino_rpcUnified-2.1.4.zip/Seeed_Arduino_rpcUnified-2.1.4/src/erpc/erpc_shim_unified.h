#ifndef ERPC_SHIM_UNIFIE_H
#define ERPC_SHIM_UNIFIE_H
#include "rpc_system_header.h"
#include "rpc_system.h"
#include "rpc_ble_api.h"
#include "rpc_ble_callback.h"
#include "rpc_ble_callback_server.h"
#include "rpc_wifi_api.h"
#include "rpc_wifi_callback.h"
#include "rpc_wifi_callback_server.h"

#endif