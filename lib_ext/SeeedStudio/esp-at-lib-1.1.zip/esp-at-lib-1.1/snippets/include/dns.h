#ifndef SNIPPET_HDR_DNS_H
#define SNIPPET_HDR_DNS_H

#ifdef __cplusplus
extern "C" {
#endif

void dns_start(void);

#ifdef __cplusplus
}
#endif

#endif
