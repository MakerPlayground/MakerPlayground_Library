#ifndef SNIPPET_HDR_NETCONN_CLIENT_H
#define SNIPPET_HDR_NETCONN_CLIENT_H

#ifdef __cplusplus
extern "C" {
#endif

void netconn_client_thread(void const* arg);

#ifdef __cplusplus
}
#endif

#endif
