#ifndef SNIPPET_HDR_NETCONN_SERVER_H
#define SNIPPET_HDR_NETCONN_SERVER_H

#ifdef __cplusplus
extern "C" {
#endif

void netconn_server_thread(void const* arg);

#ifdef __cplusplus
}
#endif

#endif
