#ifndef SNIPPET_HDR_MQTT_CLIENT_H
#define SNIPPET_HDR_MQTT_CLIENT_H

#ifdef __cplusplus
extern "C" {
#endif

void mqtt_client_thread(void const* arg);

#ifdef __cplusplus
}
#endif

#endif
