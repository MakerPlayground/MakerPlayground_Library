.. _api_esp_unicode:

Unicode
=======

Unicode decoder block. It can decode sequence of *UTF-8* characters,
between ``1`` and ``4`` bytes long.

.. note::
    This is simple implementation and does not support string encoding.

.. doxygengroup:: ESP_UNICODE