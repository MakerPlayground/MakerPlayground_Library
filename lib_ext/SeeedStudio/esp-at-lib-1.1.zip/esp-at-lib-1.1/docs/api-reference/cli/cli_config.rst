.. _api_cli_config:

CLI Configuration
=================

.. doxygengroup:: CLI_CONFIG