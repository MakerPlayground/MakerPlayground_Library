.. _api_cli_input:

CLI Input module
================

.. doxygengroup:: CLI_INPUT
	