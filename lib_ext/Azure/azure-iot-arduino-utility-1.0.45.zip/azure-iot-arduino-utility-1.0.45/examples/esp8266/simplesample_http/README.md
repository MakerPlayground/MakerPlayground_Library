### simplesample_http

Instructions for this sample are
[here in the Azure IoT HTTP protocol library for Arduino.](https://github.com/Azure/azure-iot-arduino-protocol-http)