Arduino DHTxx (xx=11,12,22,44) library
This is an Arduino library for the DHT11, DHT12, DHT22, DHT33, DHT44 and clone temperature and humidity sensors.
Read more on http://playground.arduino.cc/Main/Dht

This library needs to be compiled with C++11 features enabled -- any Arduino IDE later than 2015 will do that.
